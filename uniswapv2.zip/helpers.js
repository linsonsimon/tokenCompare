const axios = require("axios");

require("dotenv").config();
const ETHERSCAN_API_KEY = process.env.ETHERSCAN_API_KEY;

exports.getAbi = async (address) => {
  const url = `https://api.etherscan.io/api?module=contract&action=getabi&address=${address}&apikey=${ETHERSCAN_API_KEY}`;
  const res = await axios.get(url);
  const abi = JSON.parse(res.data.result);
  return abi;
};

exports.getBinancePrice = async () => {
  const url = "https://api.binance.com/api/v3/ticker/price";
  const res = await axios.get(url);
  // console.log("res:", res.data);
  // const priceChart = JSON.parse(res.data);
  const priceChart = res.data;
  // console.log(priceChart);
  let token = priceChart.filter((token) => token.symbol === "USDCUSDT");
  console.log(token[0].symbol, "=", token[0].price);
  return token[0].price;
};

exports.getPoolImmutables = async (poolContract) => {
  const [token0, token1, fee] = await Promise.all([
    poolContract.token0(),
    poolContract.token1(),
    poolContract.fee(),
  ]);
  console.log(token0, token1);

  const immutables = {
    token0: token0,
    token1: token1,
    fee: fee,
  };

  return immutables;
};
