const { ethers } = require("ethers");
const ABI = require("./factoryABI.json");
require("dotenv").config();

const { getAbi, getBinancePrice } = require("./helpers");

const INFURA_URL = process.env.INFURA_URL;
// const ETHERSCAN_API_KEY = process.env.ETHERSCAN_API_KEY;

const FactoryAddress = "0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f";

const provider = new ethers.providers.JsonRpcProvider(INFURA_URL);

const factoryContract = new ethers.Contract(FactoryAddress, ABI, provider);

const tokenAddress0 = "0xdAC17F958D2ee523a2206206994597C13D831ec7";
const tokenAddress1 = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48";

const tokenSymobl0 = "USDT";
const tokenSymbol1 = "USDC";

const getPrice1 = async (tokenAddress0, tokenAddress1) => {
  const [poolAddress] = await Promise.all([
    factoryContract.getPair(tokenAddress0, tokenAddress1),
  ]);
  let bPrice = getBinancePrice();

  console.log(poolAddress);

  let poolAbi = await getAbi(poolAddress);

  const poolContract = new ethers.Contract(poolAddress, poolAbi, provider);
  const [price0CumulativeLast, price1CumulativeLast] = await Promise.all([
    poolContract.price0CumulativeLast(),
    poolContract.price1CumulativeLast(),
  ]);

  let ePrice = price1CumulativeLast / price0CumulativeLast;
  // console.log(price0CumulativeLast.toString(), price1CumulativeLast.toString());
  console.log(
    "USDCUSDT",
    bPrice > ePrice
      ? "binance price is greater =" + bPrice
      : "uniswap price is greater =" + ePrice
  );
};

// const getPrice2 = async (poolAddress) => {
//   let poolAbi = await getAbi(poolAddress);

//   const poolContract = new ethers.Contract(poolAddress, poolAbi, provider);
//   const [
//     price0CumulativeLast,
//     price1CumulativeLast,
//     token0Address,
//     token1Address,
//   ] = await Promise.all([
//     poolContract.price0CumulativeLast(),
//     poolContract.price1CumulativeLast(),
//     poolContract.token0(),
//     poolContract.token1(),
//   ]);

//   let [token0Abi, token1Abi] = await Promise.all([
//     getAbi(token0Address),
//     getAbi(token1Address),
//   ]);

//   let token0Contract = new ethers.Contract(token0Address, token0Abi, provider);
//   let token1Contract = new ethers.Contract(token1Address, token1Abi, provider);

//   let [token0Symbol, token1Symbol] = await Promise.all([]);

//   console.log(price0CumulativeLast.toString(), price1CumulativeLast.toString());
//   console.log(price1CumulativeLast / price0CumulativeLast);
// };

getPrice1(tokenAddress0, tokenAddress1);
